package com.example.mcvoice

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/**
 * Muestra sobre el juego los últimos comentarios del directo. No recibe toques (el juego sigue funcionando debajo).
 * Por defecto NO sale en el video (se tapa igual que la burbuja); se puede activar "mostrar en el video".
 */
class ChatService : Service() {
    companion object {
        var instance: ChatService? = null
        @Volatile var inVideo = false
        private const val MAX_LINES = 6
    }

    private class Line(val plat: String, val author: String, val text: String)

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var tv: TextView? = null
    private val lines = ArrayList<Line>()
    private val main = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { tv?.visibility = View.GONE; lines.clear() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WindowManager::class.java)
        val d = resources.displayMetrics.density
        val view = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
            background = GradientDrawable().apply { setColor(Color.parseColor("#B3000000")); cornerRadius = 12 * d }
            visibility = View.GONE
        }
        lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.6f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (8 * d).toInt(); y = (56 * d).toInt() }
        wm.addView(view, lp)
        tv = view
    }

    fun add(plat: String, author: String, text: String) {
        main.post {
            val v = tv ?: return@post
            lines.add(Line(plat, author.take(24), text.take(100)))
            while (lines.size > MAX_LINES) lines.removeAt(0)
            val sb = SpannableStringBuilder()
            lines.forEachIndexed { i, l ->
                if (i > 0) sb.append('\n')
                val s = sb.length
                sb.append(l.author)
                val color = if (l.plat == "yt") Color.parseColor("#FF8A80") else Color.parseColor("#C4A6FF")
                sb.setSpan(ForegroundColorSpan(color), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.append(": ").append(l.text)
            }
            v.text = sb
            v.visibility = View.VISIBLE
            main.removeCallbacks(hideRun)
            main.postDelayed(hideRun, 15000)             // se oculta tras 15 s sin comentarios nuevos
        }
    }

    /** Zona del panel en píxeles de pantalla [x, y, ancho, alto]; null si no hay que taparla en el video. */
    fun rectPx(): IntArray? {
        val v = tv ?: return null
        if (inVideo || v.visibility != View.VISIBLE || v.width <= 0) return null
        return intArrayOf(lp.x, lp.y, v.width, v.height)
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacks(hideRun)
        tv?.let { runCatching { wm.removeView(it) } }
        tv = null
        super.onDestroy()
    }
}
