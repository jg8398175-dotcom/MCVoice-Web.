package com.example.mcvoice

import android.media.MediaFormat
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

/** Reparte el video/audio ya codificado a hasta 3 destinos RTMP a la vez. */
class LiveManager(
    dests: List<Dest>,
    meta: RtmpPublisher.Meta,
    onStatus: (Int, String, String) -> Unit,
    needKeyframe: () -> Unit
) {
    class Dest(val index: Int, val name: String, val url: String, val key: String)

    private val pubs = dests.take(3).map { RtmpPublisher(it.index, it.name, it.url, it.key, meta, onStatus, needKeyframe) }
    @Volatile private var vh: ByteArray? = null
    @Volatile private var ah: ByteArray? = null

    fun start() {
        pubs.forEach { it.setHeaders(vh, ah); it.start() }
    }

    fun stop() { pubs.forEach { it.stop() } }

    /** Cabecera de video (SPS/PPS) desde el formato del codificador. */
    fun videoFormat(f: MediaFormat) {
        val nals = ArrayList<ByteArray>()
        for (k in listOf("csd-0", "csd-1")) {
            val bb = f.getByteBuffer(k) ?: continue
            val arr = ByteArray(bb.remaining())
            bb.duplicate().get(arr)
            nals.addAll(split(arr))
        }
        val sps = nals.firstOrNull { it.isNotEmpty() && (it[0].toInt() and 0x1F) == 7 }
        val pps = nals.firstOrNull { it.isNotEmpty() && (it[0].toInt() and 0x1F) == 8 }
        if (sps == null || pps == null || sps.size < 4) return
        val o = ByteArrayOutputStream()
        o.write(0x17); o.write(0); o.write(0); o.write(0); o.write(0)
        o.write(1); o.write(sps[1].toInt()); o.write(sps[2].toInt()); o.write(sps[3].toInt())
        o.write(0xFF); o.write(0xE1); o.write(sps.size ushr 8); o.write(sps.size); o.write(sps)
        o.write(1); o.write(pps.size ushr 8); o.write(pps.size); o.write(pps)
        val h = o.toByteArray()
        vh = h
        pubs.forEach { it.setHeaders(h, null) }
    }

    /** Cabecera de audio (AudioSpecificConfig). */
    fun audioFormat(f: MediaFormat) {
        val bb = f.getByteBuffer("csd-0") ?: return
        val asc = ByteArray(bb.remaining())
        bb.duplicate().get(asc)
        val h = byteArrayOf(0xAF.toByte(), 0) + asc
        ah = h
        pubs.forEach { it.setHeaders(null, h) }
    }

    fun video(buf: ByteBuffer, off: Int, size: Int, key: Boolean, tsMs: Long) {
        val d = buf.duplicate()
        d.position(off); d.limit(off + size)
        val src = ByteArray(size)
        d.get(src)
        val o = ByteArrayOutputStream(size + 16)
        o.write(if (key) 0x17 else 0x27); o.write(1); o.write(0); o.write(0); o.write(0)
        for (n in split(src)) {
            o.write(n.size ushr 24); o.write(n.size ushr 16); o.write(n.size ushr 8); o.write(n.size)
            o.write(n)
        }
        val body = o.toByteArray()
        pubs.forEach { it.offerVideo(body, key, tsMs) }
    }

    fun audio(buf: ByteBuffer, off: Int, size: Int, tsMs: Long) {
        val d = buf.duplicate()
        d.position(off); d.limit(off + size)
        val raw = ByteArray(size + 2)
        raw[0] = 0xAF.toByte(); raw[1] = 1
        d.get(raw, 2, size)
        pubs.forEach { it.offerAudio(raw, tsMs) }
    }

    /** Separa un bloque H.264 "Annex B" (con 00 00 00 01) en unidades NAL. */
    private fun split(src: ByteArray): List<ByteArray> {
        val res = ArrayList<ByteArray>()
        val n = src.size
        var i = 0
        var start = -1
        while (i < n) {
            var sc = 0
            if (i + 2 < n && src[i].toInt() == 0 && src[i + 1].toInt() == 0) {
                if (src[i + 2].toInt() == 1) sc = 3
                else if (i + 3 < n && src[i + 2].toInt() == 0 && src[i + 3].toInt() == 1) sc = 4
            }
            if (sc > 0) {
                if (start >= 0) res.add(src.copyOfRange(start, i))
                start = i + sc
                i += sc
            } else i++
        }
        if (start in 0 until n) res.add(src.copyOfRange(start, n))
        return res
    }
}
