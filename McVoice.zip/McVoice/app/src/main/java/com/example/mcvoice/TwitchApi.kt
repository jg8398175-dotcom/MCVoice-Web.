package com.example.mcvoice

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Twitch con código de un solo uso (flujo de dispositivo): la app muestra un código, lo escribes en la
 * página de Twitch y das permiso. Con eso la app obtiene tu clave de transmisión y pone el título del directo.
 */
object TwitchApi {
    private const val SCOPE = "channel:read:stream_key channel:manage:broadcast"
    private const val ID = "https://id.twitch.tv/oauth2"
    private const val API = "https://api.twitch.tv/helix"

    private lateinit var prefs: SharedPreferences
    @Volatile private var cancelFlag = false
    private var access = ""
    private var expiresAt = 0L

    fun init(ctx: Context) {
        if (!::prefs.isInitialized) prefs = ctx.applicationContext.getSharedPreferences("mcvoice_tw", Context.MODE_PRIVATE)
    }

    fun setClientId(id: String) { prefs.edit().putString("cid", id.trim()).apply() }
    fun clientId(): String = TwitchConfig.CLIENT_ID.ifEmpty { prefs.getString("cid", "") ?: "" }
    fun builtIn(): Boolean = TwitchConfig.CLIENT_ID.isNotEmpty()
    fun connected(): Boolean = !prefs.getString("refresh", "").isNullOrEmpty()
    fun name(): String = prefs.getString("name", "") ?: ""
    fun login(): String = prefs.getString("login", "") ?: ""
    fun cancelLogin() { cancelFlag = true }
    /** Desconectar: borra la sesión del celular y revoca el permiso en Twitch. */
    fun revokeAndLogout() {
        val rt = prefs.getString("refresh", "") ?: ""
        val cid = clientId()
        logout()
        if (rt.isEmpty() || cid.isEmpty()) return
        val th = Thread {
            try {
                val r = http("POST", "$ID/token", emptyMap(), "application/x-www-form-urlencoded",
                    form("client_id" to cid, "grant_type" to "refresh_token", "refresh_token" to rt))
                val at = json(r.body).optString("access_token")
                if (at.isNotEmpty()) http("POST", "$ID/revoke", emptyMap(), "application/x-www-form-urlencoded", form("client_id" to cid, "token" to at))
            } catch (e: Exception) { }
        }
        th.isDaemon = true
        th.start()
    }
    fun logout() { prefs.edit().remove("refresh").remove("name").remove("login").remove("uid").apply(); access = ""; expiresAt = 0L }

    private class Resp(val code: Int, val body: String)

    private fun http(method: String, url: String, headers: Map<String, String>, contentType: String?, body: ByteArray?): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 30000
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (contentType != null) c.setRequestProperty("Content-Type", contentType)
        if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body) } }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        return Resp(code, text)
    }

    private fun form(vararg kv: Pair<String, String>): ByteArray =
        kv.joinToString("&") { URLEncoder.encode(it.first, "UTF-8") + "=" + URLEncoder.encode(it.second, "UTF-8") }.toByteArray()

    private fun json(s: String): JSONObject = try { if (s.isBlank()) JSONObject() else JSONObject(s) } catch (e: Exception) { JSONObject() }
    private fun err(j: JSONObject, def: String): String = j.optString("message").ifEmpty { j.optString("error_description").ifEmpty { def } }

    private fun authHeaders(t: String) = mapOf("Authorization" to "Bearer $t", "Client-Id" to clientId())

    fun startLogin(onCode: (String, String) -> Unit, onDone: (Boolean, String) -> Unit) {
        cancelFlag = false
        val th = Thread {
            try {
                val cid = clientId()
                if (cid.isEmpty()) { onDone(false, "Falta el ID de cliente de Twitch."); return@Thread }
                val r = http("POST", "$ID/device", emptyMap(), "application/x-www-form-urlencoded", form("client_id" to cid, "scopes" to SCOPE))
                val j = json(r.body)
                if (r.code != 200) { onDone(false, err(j, "No pude iniciar el acceso con Twitch. Revisa el ID de cliente (tipo Public).")); return@Thread }
                val deviceCode = j.getString("device_code")
                onCode(j.getString("user_code"), j.optString("verification_uri", "https://www.twitch.tv/activate"))
                var interval = j.optInt("interval", 5)
                val end = System.currentTimeMillis() + j.optInt("expires_in", 1800) * 1000L
                while (!cancelFlag && System.currentTimeMillis() < end) {
                    Thread.sleep(interval * 1000L)
                    val t2 = http("POST", "$ID/token", emptyMap(), "application/x-www-form-urlencoded", form(
                        "client_id" to cid, "scopes" to SCOPE, "device_code" to deviceCode,
                        "grant_type" to "urn:ietf:params:oauth:grant-type:device_code"))
                    val tj = json(t2.body)
                    if (tj.has("access_token")) {
                        access = tj.getString("access_token")
                        expiresAt = System.currentTimeMillis() + (tj.optInt("expires_in", 3600) - 60) * 1000L
                        prefs.edit().putString("refresh", tj.optString("refresh_token")).apply()
                        val me = http("GET", "$API/users", authHeaders(access), null, null)
                        val u = json(me.body).optJSONArray("data")?.optJSONObject(0)
                        val nm = u?.optString("display_name") ?: ""
                        prefs.edit().putString("name", nm).putString("login", u?.optString("login") ?: "")
                            .putString("uid", u?.optString("id") ?: "").apply()
                        onDone(true, nm)
                        return@Thread
                    }
                    val m = tj.optString("message")
                    when {
                        m.contains("pending", true) -> { }
                        m.contains("slow", true) -> interval += 5
                        m.contains("denied", true) -> { onDone(false, "Cancelaste el permiso en Twitch."); return@Thread }
                        m.contains("expired", true) || m.contains("invalid device", true) -> { onDone(false, "El código venció. Inténtalo de nuevo."); return@Thread }
                        else -> { onDone(false, err(tj, "Twitch rechazó la conexión.")); return@Thread }
                    }
                }
                onDone(false, if (cancelFlag) "Cancelado." else "El código venció. Inténtalo de nuevo.")
            } catch (e: Exception) {
                onDone(false, "Sin conexión o error: " + (e.message ?: ""))
            }
        }
        th.isDaemon = true
        th.start()
    }

    @Synchronized
    private fun token(): String? {
        if (access.isNotEmpty() && System.currentTimeMillis() < expiresAt) return access
        val rt = prefs.getString("refresh", "") ?: ""
        if (rt.isEmpty()) return null
        val r = http("POST", "$ID/token", emptyMap(), "application/x-www-form-urlencoded",
            form("client_id" to clientId(), "grant_type" to "refresh_token", "refresh_token" to rt))
        val j = json(r.body)
        if (!j.has("access_token")) { if (r.code == 400 || r.code == 401) logout(); return null }
        access = j.getString("access_token")
        expiresAt = System.currentTimeMillis() + (j.optInt("expires_in", 3600) - 60) * 1000L
        j.optString("refresh_token").takeIf { it.isNotEmpty() }?.let { prefs.edit().putString("refresh", it).apply() }
        return access
    }

    /** Pone el título del directo y devuelve la dirección y la clave de transmisión. */
    fun prepare(title: String): JSONObject {
        val t = token() ?: throw Exception("Tu sesión de Twitch venció. Vuelve a conectar.")
        val uid = prefs.getString("uid", "") ?: ""
        if (uid.isEmpty()) throw Exception("Vuelve a conectar Twitch.")
        var warn = ""
        if (title.isNotBlank()) {
            val r = http("PATCH", "$API/channels?broadcaster_id=$uid", authHeaders(t), "application/json",
                JSONObject().put("title", title.take(140)).toString().toByteArray())
            if (r.code !in 200..299) warn = "No pude poner el título en Twitch: " + err(json(r.body), "error ${r.code}")
        }
        val k = http("GET", "$API/streams/key?broadcaster_id=$uid", authHeaders(t), null, null)
        val key = json(k.body).optJSONArray("data")?.optJSONObject(0)?.optString("stream_key") ?: ""
        if (k.code !in 200..299 || key.isEmpty()) throw Exception(err(json(k.body), "No pude obtener tu clave de Twitch."))
        return JSONObject().put("ok", true).put("url", "rtmp://live.twitch.tv/app").put("key", key).put("warn", warn)
    }
}
