package com.example.mcvoice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.*
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {
    companion object {
        var web: WebView? = null
        fun runJs(code: String) { web?.post { web?.evaluateJavascript(code, null) } }
    }

    private lateinit var webView: WebView
    private var pendingPerm: PermissionRequest? = null
    private var pendingLive: String? = null
    private var filePathCb: ValueCallback<Array<Uri>>? = null
    private val fileChooser = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        filePathCb?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
        filePathCb = null
    }

    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val p = pendingPerm; pendingPerm = null
        if (p != null) { if (ok) p.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else p.deny() }
    }
    private val recPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) launchProjection() else runJs("onRecState(false)")
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val projection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val pl = pendingLive
        pendingLive = null
        if (r.resultCode == Activity.RESULT_OK && r.data != null) {
            val i = Intent(this, RecorderService::class.java).putExtra("code", r.resultCode).putExtra("data", r.data)
            if (pl != null) i.putExtra("live", pl)
            startForegroundService(i)
            if (pl == null) runJs("onRecState(true)")
        } else {
            if (pl != null) runJs("onLiveSession(false)") else runJs("onRecState(false)")
        }
    }
    private val overlay = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { setupChain() }
    private val battery = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { setupChain() }

    private var wantBubble = false
    private var askedBattery = false
    private var askedOverlay = false

    /** Lleva al usuario directo a los ajustes: 1) sin restricción de batería, 2) mostrar sobre otras apps, 3) burbuja. */
    private fun setupChain() {
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !askedBattery) {
            askedBattery = true
            toast("Toca \"Permitir\" para que MC Voice siga activa en segundo plano")
            try {
                battery.launch(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                battery.launch(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
            return
        }
        if (!Settings.canDrawOverlays(this) && !askedOverlay) {
            askedOverlay = true
            toast("Activa \"Mostrar sobre otras apps\" para MC Voice")
            overlay.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (wantBubble) {
            if (Settings.canDrawOverlays(this)) startService(Intent(this, BubbleService::class.java))
            else toast("Sin el permiso de superposición no se puede mostrar la burbuja")
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun launchProjection() {
        projection.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }

    inner class Bridge {
        @JavascriptInterface fun startRecording() = runOnUiThread {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launchProjection()
            else recPerm.launch(Manifest.permission.RECORD_AUDIO)
        }
        @JavascriptInterface fun startLive(json: String) = runOnUiThread {
            if (RecorderService.running) {
                toast("Ya hay una grabación o un directo activo. Deténlo primero.")
                runJs("onLiveSession(false)")
                return@runOnUiThread
            }
            pendingLive = json
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launchProjection()
            else recPerm.launch(Manifest.permission.RECORD_AUDIO)
        }
        @JavascriptInterface fun showChat(on: Boolean) = runOnUiThread {
            val i = Intent(this@MainActivity, ChatService::class.java)
            if (!on) { stopService(i); return@runOnUiThread }
            if (Settings.canDrawOverlays(this@MainActivity)) startService(i)
            else {
                toast("Activa \"Mostrar sobre otras apps\" y vuelve a tocar Conectar comentarios")
                overlay.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        @JavascriptInterface fun pushChat(plat: String, author: String, text: String) {
            ChatService.instance?.add(plat, author, text)
        }
        @JavascriptInterface fun setChatInVideo(v: Boolean) { ChatService.inVideo = v }
        @JavascriptInterface fun openUrl(u: String) = runOnUiThread {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { toast("No pude abrir el enlace") }
        }
        @JavascriptInterface fun clipboard(): String = try {
            getSystemService(android.content.ClipboardManager::class.java)
                .primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString() ?: ""
        } catch (e: Exception) { "" }
        @JavascriptInterface fun testLive(i: Int, name: String, url: String, key: String) {
            if (RecorderService.running) { runJs("onLiveState($i,'error','Detén el directo para poder probar.')"); return }
            RtmpPublisher(
                i, name, url, key, RtmpPublisher.Meta(1280, 720, 30, 3000),
                { idx, st, msg -> runJs("onLiveState($idx,'$st','" + msg.replace("'", " ").replace("\n", " ") + "')") },
                { }, true
            ).start()
        }
        @JavascriptInterface fun ytSetup(cid: String, sec: String) {
            YouTubeApi.init(this@MainActivity); YouTubeApi.setCredentials(cid, sec)
        }
        @JavascriptInterface fun ytStatus(): String {
            YouTubeApi.init(this@MainActivity)
            return org.json.JSONObject().put("connected", YouTubeApi.connected())
                .put("name", YouTubeApi.channelName()).put("cid", YouTubeApi.clientId())
                .put("builtIn", YouTubeApi.builtIn()).put("ready", YouTubeApi.hasCredentials()).toString()
        }
        @JavascriptInterface fun ytLogin() {
            YouTubeApi.init(this@MainActivity)
            YouTubeApi.startLogin(
                { code, url -> runJs("onYtLogin(" + org.json.JSONObject().put("code", code).put("url", url) + ")") },
                { ok, msg -> runJs("onYtState(" + org.json.JSONObject().put("connected", ok).put("name", if (ok) msg else "").put("error", if (ok) "" else msg) + ")") }
            )
        }
        @JavascriptInterface fun ytCancel() { YouTubeApi.cancelLogin() }
        @JavascriptInterface fun ytLogout() { YouTubeApi.init(this@MainActivity); YouTubeApi.revokeAndLogout() }
        @JavascriptInterface fun ytToken(): String {
            YouTubeApi.init(this@MainActivity)
            return try { YouTubeApi.token() ?: "" } catch (e: Exception) { "" }
        }
        @JavascriptInterface fun ytCreate(title: String, desc: String, privacy: String, thumb: String) {
            YouTubeApi.init(this@MainActivity)
            Thread {
                val res = try { YouTubeApi.create(title, desc, privacy, thumb) }
                catch (e: Exception) { org.json.JSONObject().put("ok", false).put("error", e.message ?: "Error de YouTube") }
                runJs("onYtCreated($res)")
            }.start()
        }
        @JavascriptInterface fun ytTransition(id: String, status: String) {
            YouTubeApi.init(this@MainActivity)
            Thread {
                val res = try { YouTubeApi.transition(id, status); org.json.JSONObject().put("ok", true).put("status", status) }
                catch (e: Exception) { org.json.JSONObject().put("ok", false).put("status", status).put("error", e.message ?: "") }
                runJs("onYtTransition($res)")
            }.start()
        }
        @JavascriptInterface fun ytEnd(id: String) {
            YouTubeApi.init(this@MainActivity)
            Thread {
                val res = try { org.json.JSONObject().put("ok", true).put("how", YouTubeApi.end(id)) }
                catch (e: Exception) { org.json.JSONObject().put("ok", false).put("error", e.message ?: "Error de YouTube") }
                runJs("onYtEnded($res)")
            }.start()
        }
        @JavascriptInterface fun ytPending() {
            YouTubeApi.init(this@MainActivity)
            Thread {
                val res = try { YouTubeApi.pending() }
                catch (e: Exception) { org.json.JSONObject().put("ok", false).put("error", e.message ?: "Error de YouTube") }
                runJs("onYtPending($res)")
            }.start()
        }
        // ---- Twitch
        @JavascriptInterface fun twSetup(cid: String) { TwitchApi.init(this@MainActivity); TwitchApi.setClientId(cid) }
        @JavascriptInterface fun twStatus(): String {
            TwitchApi.init(this@MainActivity)
            return org.json.JSONObject().put("connected", TwitchApi.connected()).put("name", TwitchApi.name())
                .put("login", TwitchApi.login()).put("cid", TwitchApi.clientId()).put("builtIn", TwitchApi.builtIn())
                .put("ready", TwitchApi.clientId().isNotEmpty()).toString()
        }
        @JavascriptInterface fun twLogin() {
            TwitchApi.init(this@MainActivity)
            TwitchApi.startLogin(
                { code, url -> runJs("onTwLogin(" + org.json.JSONObject().put("code", code).put("url", url) + ")") },
                { ok, msg -> runJs("onTwState(" + org.json.JSONObject().put("connected", ok).put("name", if (ok) msg else "").put("error", if (ok) "" else msg) + ")") }
            )
        }
        @JavascriptInterface fun twCancel() { TwitchApi.cancelLogin() }
        @JavascriptInterface fun twLogout() { TwitchApi.init(this@MainActivity); TwitchApi.revokeAndLogout() }
        @JavascriptInterface fun twPrepare(title: String) {
            TwitchApi.init(this@MainActivity)
            Thread {
                val res = try { TwitchApi.prepare(title) }
                catch (e: Exception) { org.json.JSONObject().put("ok", false).put("error", e.message ?: "Error de Twitch") }
                runJs("onTwPrepared($res)")
            }.start()
        }
        @JavascriptInterface fun stopLive() = runOnUiThread {
            stopService(Intent(this@MainActivity, RecorderService::class.java))
        }
        @JavascriptInterface fun stopRecording() = runOnUiThread {
            stopService(Intent(this@MainActivity, RecorderService::class.java))
        }
        @JavascriptInterface fun showBubble() = runOnUiThread { wantBubble = true; setupChain() }
        @JavascriptInterface fun setupBackground() = runOnUiThread { askedBattery = false; askedOverlay = false; setupChain() }
        @JavascriptInterface fun hideBubble() = runOnUiThread {
            wantBubble = false
            stopService(Intent(this@MainActivity, BubbleService::class.java))
        }
        @JavascriptInterface fun voiceService(on: Boolean) = runOnUiThread {
            val i = Intent(this@MainActivity, VoiceService::class.java)
            try {
                if (!on) stopService(i)
                else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                    startForegroundService(i)
            } catch (e: Exception) { toast("No se pudo mantener el chat en segundo plano") }
        }
        @JavascriptInterface fun setState(mode: Int) {
            BubbleService.mode = mode
            BubbleService.instance?.refresh()
        }
        @JavascriptInterface fun setPaused(p: Boolean) { RecorderService.paused = p }
        @JavascriptInterface fun getSafeMode(): Boolean =
            getSharedPreferences("mcvoice", android.content.Context.MODE_PRIVATE).getBoolean("safe", false)
        @JavascriptInterface fun setSafeMode(v: Boolean) {
            getSharedPreferences("mcvoice", android.content.Context.MODE_PRIVATE).edit().putBoolean("safe", v).apply()
        }
        @JavascriptInterface fun pushAudio(b64: String) {
            if (!RecorderService.running || RecorderService.paused) return
            try {
                val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                val shorts = ShortArray(bytes.size / 2)
                java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
                Pcm.put(shorts, shorts.size)
            } catch (e: Exception) { }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            setBackgroundColor(0xFF1D2024.toInt())
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(r.url)
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                    filePathCb?.onReceiveValue(null)
                    filePathCb = cb
                    return try { fileChooser.launch("image/*"); true } catch (e: Exception) { filePathCb = null; false }
                }
                override fun onPermissionRequest(req: PermissionRequest) {
                    runOnUiThread {
                        if (!req.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) { req.deny(); return@runOnUiThread }
                        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                            req.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                        else { pendingPerm = req; micPerm.launch(Manifest.permission.RECORD_AUDIO) }
                    }
                }
            }
        }
        web = webView
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        // Atrás = mandar a segundo plano (no cerrar la sala)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { moveTaskToBack(true) }
        })
    }

    // Que el WebView siga activo (micrófono y sala) cuando sales a Minecraft
    override fun onPause() { super.onPause(); webView.onResume(); webView.resumeTimers() }
    override fun onStop() { super.onStop(); webView.onResume(); webView.resumeTimers() }

    override fun onDestroy() {
        if (isFinishing) {
            stopService(Intent(this, BubbleService::class.java))
            stopService(Intent(this, ChatService::class.java))
            stopService(Intent(this, VoiceService::class.java))
            web = null
        }
        super.onDestroy()
    }
}
