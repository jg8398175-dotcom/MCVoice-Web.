package com.example.mcvoice

import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.Surface
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Captura pantalla + audio. Sirve para:
 *  - GRABAR en MP4 (Películas/MCVoice), con orientación automática (archivo nuevo si giras el celular).
 *  - TRANSMITIR EN DIRECTO por RTMP a hasta 3 destinos a la vez (opcionalmente guardando también una copia).
 * Pausa: no se escribe video ni audio. Congelar: solo se descarta el video (el audio sigue); se usa mientras
 * el menú de la burbuja está abierto. La burbuja se tapa en el video con un relleno del color de alrededor.
 */
class RecorderService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var paused = false
        @Volatile var freezeVideo = false
        @Volatile var cropActive = false
        @Volatile var ghost = false           // true = modo seguro: la burbuja se oculta mientras se graba
        @Volatile var glError: String? = null
        @Volatile var liveActive = false
    }

    private var projection: MediaProjection? = null
    private var worker: Thread? = null
    @Volatile private var stopFlag = false
    @Volatile private var dropVideo = false
    @Volatile private var baseUs = 0L
    @Volatile private var pauseOffsetUs = 0L
    private var stamp = 0L
    private var aFormat: MediaFormat? = null
    private lateinit var aenc: MediaCodec
    @Volatile private var live: LiveManager? = null
    @Volatile private var curVenc: MediaCodec? = null
    private var liveJson: String? = null
    private var saveFile = true

    private class Pending(val track: Int, val data: ByteBuffer, val info: MediaCodec.BufferInfo)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (worker != null) return START_NOT_STICKY
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java) else intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        liveJson = intent?.getStringExtra("live")
        val lj = liveJson
        saveFile = if (lj == null) true else (try { JSONObject(lj).optBoolean("save", false) } catch (e: Exception) { false })
        liveActive = lj != null

        startForeground(
            2, buildNotif(if (lj != null) "Transmitiendo en directo" else "Grabando pantalla"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopFlag = true }
        }, null)
        projection = p

        paused = false; freezeVideo = false; dropVideo = false; pauseOffsetUs = 0L; aFormat = null
        Pcm.clear()
        running = true
        BubbleService.instance?.refresh()
        worker = Thread {
            var err: String? = null
            try { record(p) } catch (e: Exception) { Log.e("Rec", "falló la captura", e); err = e.javaClass.simpleName + ": " + e.message }
            try { live?.stop() } catch (e: Exception) { }
            live = null
            running = false; paused = false; freezeVideo = false; cropActive = false
            val wasLive = liveActive
            liveActive = false
            BubbleService.instance?.refresh()
            if (wasLive) MainActivity.runJs("onLiveSession(false)")
            if (!wasLive || saveFile) MainActivity.runJs("onRecState(false)")
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                val msg = when {
                    err != null -> "No se pudo: $err"
                    wasLive && !saveFile -> "Directo terminado"
                    else -> "Terminado. Revisa Películas/MCVoice"
                }
                android.widget.Toast.makeText(applicationContext, msg, android.widget.Toast.LENGTH_LONG).show()
            }
            stopSelf()
        }.also { it.start() }
        return START_NOT_STICKY
    }

    /** Límite suave: transparente hasta ~73% y luego comprime los picos en vez de recortarlos (sin estática). */
    private fun softClip(v: Float): Short {
        val a = Math.abs(v)
        val r = if (a <= 24000f) a else minOf(32767f, 24000f + (a - 24000f) * 0.25f)
        return (if (v < 0) -r else r).toInt().toShort()
    }

    /** Zonas que no deben verse en el video: burbuja y panel de comentarios. */
    private fun maskRects(): IntArray? {
        val b = BubbleService.instance?.rectPx()
        val c = ChatService.instance?.rectPx()
        if (b == null && c == null) return null
        val r = IntArray(8)
        if (b != null) System.arraycopy(b, 0, r, 0, 4)
        if (c != null) System.arraycopy(c, 0, r, 4, 4)
        return r
    }

    private fun requestKeyFrame() {
        runCatching {
            val bn = Bundle(); bn.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
            curVenc?.setParameters(bn)
        }
    }

    // ---------- Pantalla / tamaño de video
    private fun screenSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    private fun canvas(sw: Int, sh: Int): Pair<Int, Int> {
        val cap = if (liveJson != null) 720f else 1080f          // en directo: 720p para no saturar tu internet
        val sc = minOf(1f, cap / minOf(sw, sh))
        return Pair(((sw * sc).toInt() / 16) * 16, ((sh * sc).toInt() / 16) * 16)
    }

    private class Plan(val srcW: Int, val srcH: Int, val outW: Int, val outH: Int, val crop: Boolean, val sw: Int, val sh: Int)

    private fun makePlan(sw: Int, sh: Int): Plan {
        val (vw, vh) = canvas(sw, sh)
        val safe = getSharedPreferences("mcvoice", MODE_PRIVATE).getBoolean("safe", false)
        ghost = safe
        return Plan(vw, vh, vw, vh, !safe, sw, sh)
    }

    // ---------- Un archivo MP4 (se crea otro cuando cambia la orientación) / o solo transmisión si no se guarda copia
    private inner class Segment(val plan: Plan, val startUs: Long, val index: Int) {
        val w = plan.outW
        val h = plan.outH
        val venc: MediaCodec
        val surface: Surface
        val feed: Surface
        val relay: GlRelay?
        val uri: Uri?
        val pfd: ParcelFileDescriptor?
        val muxer: MediaMuxer?
        var vTrack = -1
        var aTrack = -1
        var started = false
        var lastV = -1L
        var lastA = -1L
        var needKey = false
        var vDone = false
        val bitrate: Int
        private val pending = ArrayList<Pending>()

        init {
            bitrate = if (liveJson != null) 3_000_000 else (w * h * 30 * 0.12).toInt().coerceIn(3_000_000, 8_000_000)
            val vf = MediaFormat.createVideoFormat("video/avc", w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                setInteger(MediaFormat.KEY_FRAME_RATE, 30)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, if (liveJson != null) 2 else 1)
            }
            venc = MediaCodec.createEncoderByType("video/avc")
            venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = venc.createInputSurface()
            venc.start()
            curVenc = venc
            var r: GlRelay? = null
            if (plan.crop) {
                try {
                    val margin = 8f * resources.displayMetrics.density
                    r = GlRelay(surface, plan.srcW, plan.srcH, w, h, plan.sw, plan.sh, margin) { maskRects() }
                }
                catch (e: Throwable) { Log.e("Rec", "GL falló, grabo sin recorte", e); glError = e.message ?: e.javaClass.simpleName }
            }
            relay = r
            feed = r?.inputSurface ?: surface

            if (saveFile) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "MCVoice_$stamp" + (if (index > 1) "_$index" else "") + ".mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MCVoice")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)!!
                val d = contentResolver.openFileDescriptor(u, "rw")!!
                uri = u
                pfd = d
                muxer = MediaMuxer(d.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            } else {
                uri = null
                pfd = null
                muxer = null
            }
        }

        fun addTrack(f: MediaFormat): Int = muxer?.addTrack(f) ?: 0

        fun maybeStart() {
            if (!started && vTrack >= 0 && aTrack >= 0) {
                val m = muxer
                if (m != null) {
                    m.start()
                    for (pd in pending) m.writeSampleData(pd.track, pd.data, pd.info)
                    pending.clear()
                }
                started = true
            }
        }

        fun write(track: Int, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
            val m = muxer ?: return
            if (started) m.writeSampleData(track, buf, info)
            else {
                val c = ByteBuffer.allocate(info.size); c.put(buf); c.flip()
                val ci = MediaCodec.BufferInfo(); ci.set(0, info.size, info.presentationTimeUs, info.flags)
                pending.add(Pending(track, c, ci))
            }
        }

        fun drainVideo() {
            val info = MediaCodec.BufferInfo()
            while (true) {
                val idx = venc.dequeueOutputBuffer(info, 0)
                if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) return
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    vTrack = addTrack(venc.outputFormat)
                    live?.videoFormat(venc.outputFormat)
                    maybeStart()
                    continue
                }
                if (idx < 0) continue
                val buf = venc.getOutputBuffer(idx)!!
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                if (info.size > 0 && !dropVideo) {
                    var ok = true
                    if (needKey) {
                        if (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0) needKey = false else ok = false
                    }
                    if (ok) {
                        val gpts = info.presentationTimeUs - baseUs - pauseOffsetUs
                        live?.video(buf, info.offset, info.size, info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0, maxOf(0L, gpts) / 1000)
                        if (saveFile) {
                            var pts = gpts - startUs
                            if (pts < 0) pts = 0
                            if (pts <= lastV) pts = lastV + 1
                            lastV = pts
                            info.presentationTimeUs = pts
                            buf.position(info.offset); buf.limit(info.offset + info.size)
                            write(vTrack, buf, info)
                        }
                    }
                }
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) vDone = true
                venc.releaseOutputBuffer(idx, false)
            }
        }

        fun finish() {
            runCatching { relay?.release() }
            runCatching { venc.signalEndOfInputStream() }
            val end = System.currentTimeMillis() + 1500
            while (!vDone && System.currentTimeMillis() < end) { drainVideo(); Thread.sleep(10) }
            val m = muxer
            runCatching { if (started && m != null) m.stop() }
            runCatching { m?.release() }
            runCatching { venc.stop(); venc.release() }
            runCatching { surface.release() }
            runCatching { pfd?.close() }
            val u = uri
            if (u != null) {
                if (started) {
                    val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(u, v, null, null)
                } else contentResolver.delete(u, null, null)
            }
        }
    }

    private fun drainAudio(seg: Segment): Boolean {
        val info = MediaCodec.BufferInfo()
        var eos = false
        while (true) {
            val idx = aenc.dequeueOutputBuffer(info, 0)
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) return eos
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                aFormat = aenc.outputFormat
                seg.aTrack = seg.addTrack(aenc.outputFormat)
                live?.audioFormat(aenc.outputFormat)
                seg.maybeStart()
                continue
            }
            if (idx < 0) continue
            val buf = aenc.getOutputBuffer(idx)!!
            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
            if (info.size > 0 && seg.aTrack >= 0) {
                live?.audio(buf, info.offset, info.size, maxOf(0L, info.presentationTimeUs) / 1000)
                if (saveFile) {
                    var pts = info.presentationTimeUs - seg.startUs
                    if (pts >= 0) {
                        if (pts <= seg.lastA) pts = seg.lastA + 1
                        seg.lastA = pts
                        info.presentationTimeUs = pts
                        buf.position(info.offset); buf.limit(info.offset + info.size)
                        seg.write(seg.aTrack, buf, info)
                    }
                }
            }
            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) eos = true
            aenc.releaseOutputBuffer(idx, false)
        }
    }

    private fun record(p: MediaProjection) {
        val dpi = resources.displayMetrics.densityDpi
        val rate = 44100
        val frame = 1024

        // ---- Audio del juego (captura del sistema). Solo Minecraft si está instalado (sin voces duplicadas).
        val afmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        val bufSize = maxOf(
            AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 8192
        ) * 2
        val mcUid = try { packageManager.getApplicationInfo("com.mojang.minecraftpe", 0).uid } catch (e: Exception) { -1 }
        fun capture(m: Int): AudioRecord {
            val b = AudioPlaybackCaptureConfiguration.Builder(p)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            if (m == 0) b.addMatchingUid(mcUid)
            if (m == 1) b.excludeUid(android.os.Process.myUid())
            return AudioRecord.Builder().setAudioPlaybackCaptureConfig(b.build())
                .setAudioFormat(afmt).setBufferSizeInBytes(bufSize).build()
        }
        val modes = if (mcUid >= 0) listOf(0, 1, 2) else listOf(1, 2)
        val playback: AudioRecord? = modes.firstNotNullOfOrNull { m ->
            try { capture(m) } catch (e: Exception) { Log.w("Rec", "captura de audio modo $m falló", e); null }
        }

        val af = MediaFormat.createAudioFormat("audio/mp4a-latm", rate, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        aenc = MediaCodec.createEncoderByType("audio/mp4a-latm")
        aenc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        aenc.start()

        // ---- Primer archivo / transmisión, con la orientación actual
        stamp = System.currentTimeMillis()
        val t0 = System.nanoTime()
        baseUs = t0 / 1000
        val (sw0, sh0) = screenSize()
        val plan0 = makePlan(sw0, sh0)
        var seg = Segment(plan0, 0L, 1)
        cropActive = seg.relay != null
        BubbleService.instance?.refresh()
        val ge = glError
        if (ge != null) {
            glError = null
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                android.widget.Toast.makeText(applicationContext, "No pude ocultar la burbuja del video ($ge). Grabo normal: la burbuja saldrá en el video.", android.widget.Toast.LENGTH_LONG).show()
            }
        }
        val display = p.createVirtualDisplay(
            "mcvoice", plan0.srcW, plan0.srcH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, seg.feed, null, null
        )

        // ---- Directo (RTMP)
        val lj = liveJson
        if (lj != null) {
            try {
                val arr = JSONObject(lj).getJSONArray("dest")
                val dests = (0 until arr.length()).map {
                    val o = arr.getJSONObject(it)
                    LiveManager.Dest(o.optInt("i", it), o.optString("name"), o.optString("url"), o.optString("key"))
                }
                val lm = LiveManager(
                    dests, RtmpPublisher.Meta(plan0.outW, plan0.outH, 30, seg.bitrate / 1000),
                    { i, st, msg -> MainActivity.runJs("onLiveState($i,'$st','" + msg.replace("'", " ").replace("\n", " ") + "')") },
                    { requestKeyFrame() }
                )
                live = lm
                lm.start()
                MainActivity.runJs("onLiveSession(true)")
            } catch (e: Exception) {
                Log.e("Rec", "directo", e)
                MainActivity.runJs("onLiveState(0,'error','Configuración del directo no válida')")
            }
        }

        playback?.startRecording()
        val mixIn = ShortArray(frame); val pb = ShortArray(frame); val out = ShortArray(frame)
        var frameIdx = 0L
        var pausedAtUs = -1L
        var lastAudioPts = 0L
        var aDone = false; var eosSent = false; var deadline = 0L

        while (true) {
            if (!stopFlag) {
                val targetNs = t0 + frameIdx * frame * 1_000_000_000L / rate
                val waitMs = (targetNs - System.nanoTime()) / 1_000_000
                if (waitMs > 0) Thread.sleep(waitMs)
                val clockUs = (targetNs - t0) / 1000
                frameIdx++

                // ¿Giró la pantalla? -> archivo nuevo con la orientación nueva (no en directo: la resolución no puede cambiar)
                if (liveJson == null && frameIdx % 20L == 0L) {
                    val (cw, ch) = screenSize()
                    if ((cw > ch) != (seg.w > seg.h)) {
                        BubbleService.instance?.clampTo(cw, ch)
                        val np = makePlan(cw, ch)
                        val old = seg
                        val ns = Segment(np, clockUs - pauseOffsetUs, old.index + 1)
                        val f = aFormat
                        if (f != null) ns.aTrack = ns.addTrack(f)
                        display.resize(np.srcW, np.srcH, dpi)
                        display.surface = ns.feed
                        seg = ns
                        cropActive = ns.relay != null
                        BubbleService.instance?.refresh()
                        old.finish()
                    }
                }

                if (paused) {
                    if (pausedAtUs < 0) pausedAtUs = clockUs
                    Pcm.take(mixIn, frame)
                    playback?.read(pb, 0, frame, AudioRecord.READ_NON_BLOCKING)
                } else {
                    if (pausedAtUs >= 0) { pauseOffsetUs += clockUs - pausedAtUs; pausedAtUs = -1 }
                    val n1 = Pcm.take(mixIn, frame)
                    val n2 = if (playback != null) maxOf(playback.read(pb, 0, frame, AudioRecord.READ_NON_BLOCKING), 0) else 0
                    for (i in 0 until frame) {
                        val x = if (i < n1) mixIn[i].toFloat() else 0f
                        val y = if (i < n2) pb[i] * 0.35f else 0f               // el juego suena más bajo que las voces
                        out[i] = softClip(x + y)
                    }
                    val ii = aenc.dequeueInputBuffer(5_000)
                    if (ii >= 0) {
                        val ib = aenc.getInputBuffer(ii)!!
                        ib.clear(); ib.order(ByteOrder.LITTLE_ENDIAN)
                        ib.asShortBuffer().put(out, 0, frame)
                        val pts = clockUs - pauseOffsetUs
                        lastAudioPts = pts
                        aenc.queueInputBuffer(ii, 0, frame * 2, pts, 0)
                    }
                }

                // Descartar video si hay pausa o el menú de la burbuja está abierto
                val wantDrop = paused || freezeVideo
                if (wantDrop && !dropVideo) dropVideo = true
                else if (!wantDrop && dropVideo) {
                    dropVideo = false
                    seg.needKey = true
                    requestKeyFrame()
                }
            } else if (!eosSent) {
                var tries = 0
                while (tries++ < 50) {
                    val ii = aenc.dequeueInputBuffer(20_000)
                    if (ii >= 0) {
                        aenc.queueInputBuffer(ii, 0, 0, lastAudioPts + 1000, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        break
                    }
                }
                eosSent = true; deadline = System.currentTimeMillis() + 3000
            } else {
                Thread.sleep(10)
                if (aDone || System.currentTimeMillis() > deadline) break
            }
            if (drainAudio(seg)) aDone = true
            seg.drainVideo()
        }

        // ---- Cierre
        runCatching { display.release() }
        seg.finish()
        runCatching { aenc.stop(); aenc.release() }
        runCatching { playback?.stop(); playback?.release() }
    }

    override fun onDestroy() {
        stopFlag = true
        worker?.join(6000)
        projection?.stop()
        super.onDestroy()
    }
}
