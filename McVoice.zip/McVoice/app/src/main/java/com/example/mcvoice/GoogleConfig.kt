package com.example.mcvoice

/**
 * Credenciales de Google de la app. Se crean UNA sola vez (en Google Cloud, tipo "TV y dispositivos de
 * entrada limitada") y se pegan aquí antes de compilar. Así, quien use la app solo ve "Conectar con YouTube":
 * nadie tiene que copiar IDs ni secretos.
 *
 * Si quedan vacías, la app te pide pegarlas una vez en la pantalla de conexión.
 */
object GoogleConfig {
    const val CLIENT_ID = ""
    const val CLIENT_SECRET = ""
}
