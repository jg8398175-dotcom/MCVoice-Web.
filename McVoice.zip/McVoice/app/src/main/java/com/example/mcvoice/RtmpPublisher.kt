package com.example.mcvoice

import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.concurrent.withLock

/**
 * Envía video H.264 + audio AAC a un servidor RTMP/RTMPS (YouTube, Twitch, Facebook, TikTok LIVE Studio, etc.).
 * Un publicador por destino; todos reciben los mismos cuadros ya codificados.
 */
class RtmpPublisher(
    val index: Int,
    private val label: String,
    url: String,
    key: String,
    private val meta: Meta,
    private val onStatus: (Int, String, String) -> Unit,
    private val needKeyframe: () -> Unit,
    private val testOnly: Boolean = false
) {
    class Meta(val width: Int, val height: Int, val fps: Int, val videoKbps: Int)
    private class Pkt(val type: Int, val ts: Long, val data: ByteArray)

    private val secure: Boolean
    private val host: String
    private val port: Int
    private val app: String
    private val streamName: String
    private val tcUrl: String

    private val q = LinkedBlockingQueue<Pkt>()
    @Volatile private var running = true
    @Volatile private var ready = false
    @Volatile private var waitKey = true
    @Volatile private var failed = false
    @Volatile private var vHeader: ByteArray? = null
    @Volatile private var aHeader: ByteArray? = null
    @Volatile private var sockRef: Socket? = null
    private var chunkSize = 128

    private val lock = ReentrantLock()
    private val cond = lock.newCondition()
    private val seen = StringBuilder()
    @Volatile private var peerClosed = false

    init {
        val u = url.trim()
        secure = u.startsWith("rtmps://", ignoreCase = true)
        val rest = u.substringAfter("://")
        val hostPort = rest.substringBefore('/')
        host = hostPort.substringBefore(':')
        port = hostPort.substringAfter(':', "").toIntOrNull() ?: (if (secure) 443 else 1935)
        var path = rest.substringAfter('/', "").trimEnd('/')
        var k = key.trim()
        if (k.isEmpty() && path.contains('/')) { k = path.substringAfterLast('/'); path = path.substringBeforeLast('/') }
        app = path
        streamName = k
        tcUrl = (if (secure) "rtmps://" else "rtmp://") + hostPort + "/" + app
    }

    fun setHeaders(v: ByteArray?, a: ByteArray?) {
        if (v != null) vHeader = v
        if (a != null) aHeader = a
    }

    fun start() {
        val t = Thread({ run() }, "rtmp-$index")
        t.isDaemon = true
        t.start()
    }

    fun stop() {
        running = false
        q.clear()
        try { sockRef?.close() } catch (e: Exception) { }
    }

    fun offerVideo(data: ByteArray, key: Boolean, ts: Long) {
        if (!ready) return
        if (waitKey) { if (!key) return; waitKey = false }
        if (q.size > 400 && !key) { waitKey = true; needKeyframe(); return }     // red lenta: se descartan cuadros hasta el siguiente clave
        q.offer(Pkt(9, ts, data))
    }

    fun offerAudio(data: ByteArray, ts: Long) {
        if (!ready || q.size > 900) return
        q.offer(Pkt(8, ts, data))
    }

    // ------------------------------------------------------------------ conexión
    private fun run() {
        try {
            onStatus(index, "conectando", "")
            val plain = Socket()
            plain.connect(InetSocketAddress(host, port), 10_000)
            plain.tcpNoDelay = true
            val s: Socket = if (secure) {
                val ss = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(plain, host, port, true) as SSLSocket
                ss.startHandshake()
                ss
            } else plain
            sockRef = s
            val out = BufferedOutputStream(s.getOutputStream(), 32768)
            val inp = s.getInputStream()
            handshake(out, inp)
            startReader(inp)

            send(out, 2, 1, 0, 0, byteArrayOf(0, 0, 0x10, 0))          // tamaño de bloque = 4096
            chunkSize = 4096
            send(out, 3, 20, 0, 0, amf {
                str("connect"); num(1.0)
                objStart(); key("app"); str(app); key("type"); str("nonprivate")
                key("flashVer"); str("FMLE/3.0 (compatible; FMSc/1.0)"); key("tcUrl"); str(tcUrl); objEnd()
            })
            out.flush()
            waitFor("NetConnection.Connect.Success", 10_000)

            send(out, 3, 20, 0, 0, amf { str("releaseStream"); num(2.0); nul(); str(streamName) })
            send(out, 3, 20, 0, 0, amf { str("FCPublish"); num(3.0); nul(); str(streamName) })
            send(out, 3, 20, 0, 0, amf { str("createStream"); num(4.0); nul() })
            out.flush()
            waitFor("_result", 8_000)

            send(out, 4, 20, 1, 0, amf { str("publish"); num(5.0); nul(); str(streamName); str("live") })
            out.flush()
            waitFor("NetStream.Publish.Start", 10_000)
            if (testOnly) {
                onStatus(index, "listo", "Conexión correcta: el servidor aceptó la dirección y la clave.")
                running = false
                return
            }

            send(out, 4, 18, 1, 0, amf {
                str("@setDataFrame"); str("onMetaData")
                objStart()
                key("width"); num(meta.width.toDouble()); key("height"); num(meta.height.toDouble())
                key("framerate"); num(meta.fps.toDouble()); key("videodatarate"); num(meta.videoKbps.toDouble())
                key("videocodecid"); num(7.0); key("audiocodecid"); num(10.0)
                key("audiosamplerate"); num(44100.0); key("stereo"); bool(false)
                objEnd()
            })
            val end = System.currentTimeMillis() + 4000
            while ((vHeader == null || aHeader == null) && System.currentTimeMillis() < end && running) Thread.sleep(50)
            vHeader?.let { send(out, 7, 9, 1, 0, it) }
            aHeader?.let { send(out, 6, 8, 1, 0, it) }
            out.flush()

            waitKey = true
            ready = true
            needKeyframe()
            onStatus(index, "envivo", "")

            while (running) {
                val p = q.poll(500, TimeUnit.MILLISECONDS)
                if (p == null) { out.flush(); continue }
                send(out, if (p.type == 8) 6 else 7, p.type, 1, p.ts, p.data)
                if (q.isEmpty()) out.flush()
            }
        } catch (e: Exception) {
            if (running) { failed = true; onStatus(index, "error", friendly(e)) }
        } finally {
            ready = false
            running = false
            try { sockRef?.close() } catch (e: Exception) { }
            if (!failed && !testOnly) onStatus(index, "terminado", "Directo terminado")
        }
    }

    private fun friendly(e: Exception): String = when (e) {
        is UnknownHostException -> "No encuentro el servidor ($host). Revisa la dirección."
        is ConnectException, is SocketTimeoutException -> "No pude conectar con $host. Revisa tu internet o la dirección."
        is javax.net.ssl.SSLException -> "Error de conexión segura con $host."
        else -> e.message ?: e.javaClass.simpleName
    }

    private fun handshake(out: OutputStream, inp: InputStream) {
        val c1 = ByteArray(1536)
        java.util.Random().nextBytes(c1)
        for (i in 0 until 8) c1[i] = 0
        out.write(3); out.write(c1); out.flush()
        if (inp.read() != 3) throw IOException("El servidor no respondió como RTMP")
        val s1 = ByteArray(1536); readFully(inp, s1)
        val s2 = ByteArray(1536); readFully(inp, s2)
        out.write(s1); out.flush()
    }

    private fun readFully(inp: InputStream, b: ByteArray) {
        var o = 0
        while (o < b.size) {
            val n = inp.read(b, o, b.size - o)
            if (n < 0) throw IOException("El servidor cerró la conexión")
            o += n
        }
    }

    private class ChunkState {
        var len = 0
        var type = 0
        var remaining = 0
        var ext = false
        var buf = ByteArrayOutputStream()
    }

    private fun u24(h: ByteArray, o: Int): Int =
        ((h[o].toInt() and 0xFF) shl 16) or ((h[o + 1].toInt() and 0xFF) shl 8) or (h[o + 2].toInt() and 0xFF)

    /** Lee los mensajes del servidor completos (respeta su tamaño de bloque) y guarda su texto para buscar las respuestas. */
    private fun startReader(inp: InputStream) {
        val t = Thread {
            try {
                val states = HashMap<Int, ChunkState>()
                var inChunk = 128
                val skip4 = ByteArray(4)
                while (running) {
                    val b0 = inp.read()
                    if (b0 < 0) break
                    val fmt = b0 ushr 6
                    var csid = b0 and 0x3F
                    if (csid == 0) csid = 64 + inp.read()
                    else if (csid == 1) { val x = inp.read(); val y = inp.read(); csid = 64 + x + y * 256 }
                    val st = states.getOrPut(csid) { ChunkState() }
                    when (fmt) {
                        0 -> {
                            val h = ByteArray(11); readFully(inp, h)
                            st.ext = u24(h, 0) == 0xFFFFFF
                            st.len = u24(h, 3); st.type = h[6].toInt() and 0xFF
                            if (st.ext) readFully(inp, skip4)
                            st.remaining = st.len; st.buf = ByteArrayOutputStream()
                        }
                        1 -> {
                            val h = ByteArray(7); readFully(inp, h)
                            st.ext = u24(h, 0) == 0xFFFFFF
                            st.len = u24(h, 3); st.type = h[6].toInt() and 0xFF
                            if (st.ext) readFully(inp, skip4)
                            st.remaining = st.len; st.buf = ByteArrayOutputStream()
                        }
                        2 -> {
                            val h = ByteArray(3); readFully(inp, h)
                            st.ext = u24(h, 0) == 0xFFFFFF
                            if (st.ext) readFully(inp, skip4)
                            st.remaining = st.len; st.buf = ByteArrayOutputStream()
                        }
                        else -> {
                            if (st.remaining == 0) { st.remaining = st.len; st.buf = ByteArrayOutputStream() }
                            if (st.ext) readFully(inp, skip4)
                        }
                    }
                    val n = minOf(inChunk, st.remaining)
                    val data = ByteArray(n)
                    readFully(inp, data)
                    st.buf.write(data)
                    st.remaining -= n
                    if (st.remaining == 0) {
                        val payload = st.buf.toByteArray()
                        when (st.type) {
                            1 -> if (payload.size >= 4) {
                                inChunk = (((payload[0].toInt() and 0x7F) shl 24) or ((payload[1].toInt() and 0xFF) shl 16) or
                                    ((payload[2].toInt() and 0xFF) shl 8) or (payload[3].toInt() and 0xFF)).coerceIn(1, 1_000_000)
                            }
                            20, 17, 18 -> lock.withLock {
                                seen.append(String(payload, Charsets.ISO_8859_1)).append('\u0000')
                                if (seen.length > 20000) seen.delete(0, seen.length - 10000)
                                cond.signalAll()
                            }
                            else -> { }
                        }
                    }
                }
            } catch (e: Exception) { }
            peerClosed = true
            lock.withLock { cond.signalAll() }
        }
        t.isDaemon = true
        t.start()
    }

    private val bad = listOf(
        "NetConnection.Connect.Rejected", "NetConnection.Connect.Failed", "NetConnection.Connect.InvalidApp",
        "NetStream.Publish.BadName", "NetStream.Publish.Denied", "NetStream.Publish.Failed", "NetStream.Failed"
    )

    private fun waitFor(token: String, timeoutMs: Long) {
        val end = System.currentTimeMillis() + timeoutMs
        lock.withLock {
            while (true) {
                val i = seen.indexOf(token)
                if (i >= 0) { seen.delete(0, i + token.length); return }
                for (b in bad) if (seen.indexOf(b) >= 0) throw IOException("$label rechazó la conexión: revisa la clave y la dirección ($b).")
                if (peerClosed) throw IOException("El servidor cerró la conexión. Revisa la clave y que tu cuenta pueda hacer directos.")
                val left = end - System.currentTimeMillis()
                if (left <= 0) throw IOException("El servidor no respondió. Revisa la dirección y la clave.")
                cond.await(left, TimeUnit.MILLISECONDS)
            }
        }
    }

    // ------------------------------------------------------------------ mensajes RTMP
    private fun send(out: OutputStream, csid: Int, type: Int, streamId: Int, ts: Long, payload: ByteArray) {
        val ext = ts >= 0xFFFFFFL
        val tsField = if (ext) 0xFFFFFF else ts.toInt()
        var off = 0
        var first = true
        while (first || off < payload.size) {
            val n = minOf(chunkSize, payload.size - off)
            if (first) {
                out.write(csid)
                out.write(tsField ushr 16); out.write(tsField ushr 8); out.write(tsField)
                out.write(payload.size ushr 16); out.write(payload.size ushr 8); out.write(payload.size)
                out.write(type)
                out.write(streamId); out.write(streamId ushr 8); out.write(streamId ushr 16); out.write(streamId ushr 24)
                if (ext) writeInt(out, ts.toInt())
                first = false
            } else {
                out.write(0xC0 or csid)
                if (ext) writeInt(out, ts.toInt())
            }
            out.write(payload, off, n)
            off += n
        }
    }

    private fun writeInt(out: OutputStream, v: Int) {
        out.write(v ushr 24); out.write(v ushr 16); out.write(v ushr 8); out.write(v)
    }

    private class Amf {
        private val o = ByteArrayOutputStream()
        fun str(s: String) { val b = s.toByteArray(Charsets.UTF_8); o.write(2); o.write(b.size ushr 8); o.write(b.size); o.write(b) }
        fun num(d: Double) { o.write(0); val l = java.lang.Double.doubleToLongBits(d); for (i in 7 downTo 0) o.write((l ushr (8 * i)).toInt()) }
        fun nul() { o.write(5) }
        fun bool(b: Boolean) { o.write(1); o.write(if (b) 1 else 0) }
        fun objStart() { o.write(3) }
        fun key(k: String) { val b = k.toByteArray(Charsets.UTF_8); o.write(b.size ushr 8); o.write(b.size); o.write(b) }
        fun objEnd() { o.write(0); o.write(0); o.write(9) }
        fun bytes(): ByteArray = o.toByteArray()
    }

    private fun amf(block: Amf.() -> Unit): ByteArray {
        val a = Amf()
        a.block()
        return a.bytes()
    }
}
