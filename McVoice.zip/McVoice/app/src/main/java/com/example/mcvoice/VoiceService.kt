package com.example.mcvoice

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager

/** Mantiene la app viva con permiso de micrófono (y CPU despierta) mientras estás en otra app. */
class VoiceService : Service() {
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotif("Chat de voz activo"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        if (wl == null) {
            wl = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mcvoice:voice")
                .apply { setReferenceCounted(false); acquire() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        runCatching { wl?.release() }
        wl = null
        super.onDestroy()
    }
}
