package com.example.mcvoice

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Burbuja flotante.
 *  - Sin grabar: toque = alternar Normal <-> "Ellos no me oyen"; mantener = menú (modos + iniciar grabación).
 *  - Grabando: la burbuja se vuelve invisible (no sale en el video) pero sigue en su lugar. Un toque abre el menú
 *    (modos + pausar/reanudar) y mientras está abierto el video se congela (el audio sigue) para que el menú
 *    tampoco salga en la grabación.
 */
class BubbleService : Service() {
    companion object {
        var instance: BubbleService? = null
        @Volatile var mode = 1
        private const val FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var density = 1f
    private val main = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { hidePanel() }
    private val buildRun = Runnable { buildPanel() }
    private val unfreezeRun = Runnable { RecorderService.freezeVideo = false }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WindowManager::class.java)
        density = resources.displayMetrics.density
        val d = density
        val size = (58 * d).toInt()
        val tv = TextView(this).apply { gravity = Gravity.CENTER; textSize = 24f }
        lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, FLAGS, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (12 * d).toInt(); y = (220 * d).toInt() }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        var moved = false; var longPressed = false
        val longRun = Runnable { longPressed = true; showPanel() }
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY
                    moved = false; longPressed = false
                    main.postDelayed(longRun, 500)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (Math.abs(dx) > 12 * d || Math.abs(dy) > 12 * d) {
                        moved = true
                        main.removeCallbacks(longRun)
                    }
                    if (moved) {
                        lp.x = sx + dx.toInt()
                        lp.y = sy + dy.toInt()
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(longRun)
                    if (e.action == MotionEvent.ACTION_UP && !moved && !longPressed) {
                        if (RecorderService.running) showPanel() else MainActivity.runJs("toggleMute()")
                    }
                }
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
        refresh()
    }

    /** Zona de la burbuja en píxeles de pantalla [x, y, ancho, alto]; null si no hay que taparla en el video. */
    fun rectPx(): IntArray? {
        if (!RecorderService.running || RecorderService.ghost || bubble == null) return null
        return intArrayOf(lp.x, lp.y, lp.width, lp.height)
    }

    /** Tras girar la pantalla, mantiene la burbuja dentro de la pantalla. */
    fun clampTo(screenW: Int, screenH: Int) {
        main.post {
            lp.x = lp.x.coerceIn(0, maxOf(0, screenW - lp.width))
            lp.y = lp.y.coerceIn(0, maxOf(0, screenH - lp.height))
            bubble?.let { runCatching { wm.updateViewLayout(it, lp) } }
        }
    }

    private fun showPanel() {
        hidePanel(keepFreeze = true)
        main.removeCallbacks(unfreezeRun)
        if (RecorderService.running) {
            RecorderService.freezeVideo = true          // el video se congela antes de mostrar el menú
            main.postDelayed(buildRun, 180)
        } else buildPanel()
    }

    private fun buildPanel() {
        val d = density
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2262A2F")); cornerRadius = 14 * d
                setStroke((2 * d).toInt(), Color.parseColor("#3A3F45"))
            }
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
        }
        fun item(text: String, color: String?, onClick: () -> Unit): TextView {
            val t = TextView(this).apply {
                this.text = text; textSize = 16f; setTextColor(Color.WHITE)
                setPadding((16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt())
            }
            if (color != null) t.background = GradientDrawable().apply { setColor(Color.parseColor(color)); cornerRadius = 10 * d }
            t.setOnClickListener { onClick() }
            return t
        }
        val labels = listOf("🎤  Normal", "🔇  Ellos no me oyen", "🙉  Nadie se oye (solo grabo)")
        labels.forEachIndexed { i, t ->
            val m = i + 1
            box.addView(item(t, if (BubbleService.mode == m) "#3D7524" else null) {
                MainActivity.runJs("applyMode($m)")
                BubbleService.mode = m
                refresh()
                hidePanel()
            })
        }
        val lpItem = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = (8 * d).toInt() }
        if (RecorderService.running) {
            val label = if (RecorderService.paused) "▶  Reanudar grabación" else "⏸  Pausar grabación"
            box.addView(item(label, "#9A6B0A") {
                val np = !RecorderService.paused
                RecorderService.paused = np
                MainActivity.runJs("syncPause($np)")
                refresh()
                hidePanel()
            }, lpItem)
        } else {
            box.addView(item("🔴  Iniciar grabación", "#9C2218") {
                hidePanel()
                val i = Intent(this, ProjectionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }, lpItem)
        }
        val onRight = lp.x > resources.displayMetrics.widthPixels / 2
        val plp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            FLAGS or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (onRight) maxOf(0, lp.x - (230 * d).toInt()) else lp.x + (66 * d).toInt()
            y = lp.y
        }
        box.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) hidePanel()
            false
        }
        try {
            wm.addView(box, plp)
            panel = box
            main.postDelayed(hideRun, 6000)
        } catch (e: Exception) {
            if (RecorderService.freezeVideo) main.postDelayed(unfreezeRun, 100)
        }
    }

    private fun hidePanel(keepFreeze: Boolean = false) {
        main.removeCallbacks(hideRun)
        main.removeCallbacks(buildRun)
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        // el video vuelve unos instantes después de que el menú desaparece
        if (!keepFreeze && RecorderService.freezeVideo) main.postDelayed(unfreezeRun, 250)
    }

    fun refresh() {
        main.post {
            val tv = bubble ?: return@post
            if (RecorderService.running && RecorderService.ghost) {
                // modo seguro / sin recorte: invisible mientras se graba
                tv.background = null
                tv.text = ""
            } else {
                tv.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(when (mode) {
                        2 -> Color.parseColor("#555B61")
                        3 -> Color.parseColor("#B06A1D")
                        else -> Color.parseColor("#3D7524")
                    })
                    if (RecorderService.running) {
                        setStroke((4 * density).toInt(), Color.parseColor(if (RecorderService.paused) "#E0A21B" else "#D8392B"))
                    }
                }
                tv.text = when (mode) {
                    2 -> "🔇"
                    3 -> "🙉"
                    else -> "🎤"
                }
            }
        }
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacks(unfreezeRun)
        RecorderService.freezeVideo = false
        hidePanel(keepFreeze = true)
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        super.onDestroy()
    }
}
