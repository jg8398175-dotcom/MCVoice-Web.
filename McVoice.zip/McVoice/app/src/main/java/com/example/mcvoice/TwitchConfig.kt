package com.example.mcvoice

/**
 * ID de cliente de la app en Twitch (gratis, sin secreto). Se crea UNA sola vez en dev.twitch.tv/console
 * (tipo de cliente "Public") y se pega aquí antes de compilar. Así cada persona solo toca "Conectar con Twitch".
 * Si queda vacío, la app lo pide una vez en la pantalla de conexión.
 */
object TwitchConfig {
    const val CLIENT_ID = ""
}
