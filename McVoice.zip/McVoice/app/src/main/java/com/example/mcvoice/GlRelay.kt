package com.example.mcvoice

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch

/**
 * Recibe los cuadros de la pantalla, TAPA la zona donde está la burbuja (rellenándola con el color de alrededor)
 * y los dibuja en el codificador de video. La burbuja se ve en tu pantalla, se puede mover a cualquier lado
 * y no aparece en el video. También limita el video a ~30 cuadros por segundo para no cargar el celular.
 *
 * rect(): [x, y, ancho, alto] de la burbuja en píxeles de pantalla, o null si no hay que tapar nada.
 */
class GlRelay(
    private val outSurface: Surface,
    private val srcW: Int, private val srcH: Int,
    private val outW: Int, private val outH: Int,
    private val screenW: Int, private val screenH: Int,
    private val marginPx: Float,
    private val rect: () -> IntArray?
) {
    private val thread = HandlerThread("mcv-gl").also { it.start() }
    private val handler = Handler(thread.looper)
    lateinit var inputSurface: Surface
        private set
    @Volatile var frames = 0
        private set

    private var st: SurfaceTexture? = null
    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var surf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var texId = 0
    private var aPos = 0
    private var uTex = 0
    private var uRect = 0
    private var uRect2 = 0
    private var lastTs = 0L
    private val mtx = FloatArray(16)
    private val pos = floatBuf(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))

    init {
        val latch = CountDownLatch(1)
        var err: Throwable? = null
        handler.post {
            try { setup() } catch (t: Throwable) { err = t }
            latch.countDown()
        }
        latch.await()
        val e = err
        if (e != null) { release(); throw RuntimeException("GL: " + e.message, e) }
    }

    private fun floatBuf(a: FloatArray) = ByteBuffer.allocateDirect(a.size * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(a); position(0) }

    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src); GLES20.glCompileShader(s)
        val ok = IntArray(1); GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("shader: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    private fun setup() {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        if (!EGL14.eglInitialize(dpy, ver, 0, ver, 1)) throw RuntimeException("eglInitialize")
        fun attrs(recordable: Boolean): IntArray {
            val l = arrayListOf(
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT
            )
            if (recordable) { l.add(EGLExt.EGL_RECORDABLE_ANDROID); l.add(1) }
            l.add(EGL14.EGL_NONE)
            return l.toIntArray()
        }
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        var found = EGL14.eglChooseConfig(dpy, attrs(true), 0, cfgs, 0, 1, n, 0) && n[0] > 0
        if (!found) found = EGL14.eglChooseConfig(dpy, attrs(false), 0, cfgs, 0, 1, n, 0) && n[0] > 0
        if (!found) throw RuntimeException("eglChooseConfig")
        ctx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], outSurface, intArrayOf(EGL14.EGL_NONE), 0)
        if (!EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) throw RuntimeException("eglMakeCurrent")

        val vs = shader(GLES20.GL_VERTEX_SHADER, """
            attribute vec4 aPos; varying vec2 vPos;
            void main() { gl_Position = aPos; vPos = aPos.xy * 0.5 + 0.5; }
        """.trimIndent())
        val fs = shader(GLES20.GL_FRAGMENT_SHADER, """
            #extension GL_OES_EGL_image_external : require
            #ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
            #else
            precision mediump float;
            #endif
            varying vec2 vPos;
            uniform samplerExternalOES sTex;
            uniform mat4 uTex;
            uniform vec4 uRect;
            uniform vec4 uRect2;
            vec4 S(vec2 p) { return texture2D(sTex, (uTex * vec4(p, 0.0, 1.0)).xy); }
            bool inRect(vec4 r) {
                return r.z > r.x && vPos.x > r.x && vPos.x < r.z && vPos.y > r.y && vPos.y < r.w;
            }
            vec4 fillRect(vec4 r) {
                vec2 sz = r.zw - r.xy;
                vec2 t = (vPos - r.xy) / sz;
                float e = 0.004;
                vec4 l = S(vec2(r.x - e, vPos.y));
                vec4 rr = S(vec2(r.z + e, vPos.y));
                vec4 b = S(vec2(vPos.x, r.y - e));
                vec4 u = S(vec2(vPos.x, r.w + e));
                return 0.5 * mix(l, rr, t.x) + 0.5 * mix(b, u, t.y);
            }
            void main() {
                if (inRect(uRect)) gl_FragColor = fillRect(uRect);
                else if (inRect(uRect2)) gl_FragColor = fillRect(uRect2);
                else gl_FragColor = S(vPos);
            }
        """.trimIndent())
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs); GLES20.glAttachShader(program, fs); GLES20.glLinkProgram(program)
        val ok = IntArray(1); GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link: " + GLES20.glGetProgramInfoLog(program))
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        uTex = GLES20.glGetUniformLocation(program, "uTex")
        uRect = GLES20.glGetUniformLocation(program, "uRect")
        uRect2 = GLES20.glGetUniformLocation(program, "uRect2")

        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0); texId = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        val s = SurfaceTexture(texId)
        s.setDefaultBufferSize(srcW, srcH)
        st = s
        inputSurface = Surface(s)
        s.setOnFrameAvailableListener({ onFrame() }, handler)
    }

    private fun clamp01(v: Float) = if (v < 0f) 0f else if (v > 1f) 1f else v

    /** r = hasta dos zonas [x, y, ancho, alto, x, y, ancho, alto] en píxeles de pantalla. */
    private fun setRect(loc: Int, r: IntArray?, o: Int) {
        if (r == null || r.size < o + 4 || r[o + 2] <= 0 || r[o + 3] <= 0) { GLES20.glUniform4f(loc, 0f, 0f, 0f, 0f); return }
        val x0 = clamp01((r[o] - marginPx) / screenW)
        val x1 = clamp01((r[o] + r[o + 2] + marginPx) / screenW)
        val yTop = (r[o + 1] - marginPx) / screenH
        val yBot = (r[o + 1] + r[o + 3] + marginPx) / screenH
        GLES20.glUniform4f(loc, x0, clamp01(1f - yBot), x1, clamp01(1f - yTop))
    }

    private fun onFrame() {
        val s = st ?: return
        if (surf == EGL14.EGL_NO_SURFACE) return
        try {
            s.updateTexImage()                       // siempre se consume el cuadro
            val ts = s.timestamp
            if (lastTs != 0L && ts - lastTs < 30_000_000L) return     // ~30 cuadros por segundo como máximo
            lastTs = ts
            s.getTransformMatrix(mtx)
            GLES20.glViewport(0, 0, outW, outH)
            GLES20.glUseProgram(program)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
            GLES20.glUniformMatrix4fv(uTex, 1, false, mtx, 0)

            val r = rect()
            setRect(uRect, r, 0)
            setRect(uRect2, r, 4)
            GLES20.glEnableVertexAttribArray(aPos)
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 8, pos)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            EGLExt.eglPresentationTimeANDROID(dpy, surf, ts)
            EGL14.eglSwapBuffers(dpy, surf)
            frames++
        } catch (e: Exception) { Log.e("GlRelay", "frame", e) }
    }

    fun release() {
        if (!thread.isAlive) return
        val latch = CountDownLatch(1)
        handler.post {
            try { st?.setOnFrameAvailableListener(null) } catch (e: Exception) { }
            try {
                if (dpy != EGL14.EGL_NO_DISPLAY) {
                    EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                }
            } catch (e: Exception) { }
            try { if (surf != EGL14.EGL_NO_SURFACE) { EGL14.eglDestroySurface(dpy, surf) } } catch (e: Exception) { }
            try { if (ctx != EGL14.EGL_NO_CONTEXT) { EGL14.eglDestroyContext(dpy, ctx) } } catch (e: Exception) { }
            try { if (dpy != EGL14.EGL_NO_DISPLAY) { EGL14.eglTerminate(dpy) } } catch (e: Exception) { }
            surf = EGL14.EGL_NO_SURFACE; ctx = EGL14.EGL_NO_CONTEXT; dpy = EGL14.EGL_NO_DISPLAY
            try { if (::inputSurface.isInitialized) { inputSurface.release() } } catch (e: Exception) { }
            try { st?.release() } catch (e: Exception) { }
            latch.countDown()
        }
        latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
        thread.quitSafely()
    }
}
