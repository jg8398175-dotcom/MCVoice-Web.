package com.example.mcvoice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/** Actividad transparente: pide el permiso de grabar encima de Minecraft (así la grabación toma su orientación). */
class ProjectionActivity : ComponentActivity() {
    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK && r.data != null) {
            startForegroundService(
                Intent(this, RecorderService::class.java).putExtra("code", r.resultCode).putExtra("data", r.data)
            )
            MainActivity.runJs("onRecState(true)")
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Primero activa el micrófono dentro de MC Voice", Toast.LENGTH_LONG).show()
            finish(); return
        }
        launcher.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
}
