package com.example.mcvoice

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * YouTube Live como en Prism: inicia sesión con Google (flujo de dispositivo), crea el directo con título,
 * descripción, privacidad y miniatura, obtiene la clave de transmisión solo y lo pone en vivo / lo termina.
 * Usa las credenciales de cliente de Google que el propio usuario crea (la app no está registrada con Google).
 */
object YouTubeApi {
    private const val SCOPE = "https://www.googleapis.com/auth/youtube"
    private const val TOKEN_URL = "https://oauth2.googleapis.com/token"
    private const val API = "https://www.googleapis.com/youtube/v3"

    private lateinit var prefs: SharedPreferences
    @Volatile private var cancelFlag = false
    private var access = ""
    private var expiresAt = 0L

    fun init(ctx: Context) {
        if (!::prefs.isInitialized) prefs = ctx.applicationContext.getSharedPreferences("mcvoice_yt", Context.MODE_PRIVATE)
    }

    fun setCredentials(id: String, secret: String) {
        prefs.edit().putString("cid", id.trim()).putString("csec", secret.trim()).apply()
    }
    fun clientId(): String = GoogleConfig.CLIENT_ID.ifEmpty { prefs.getString("cid", "") ?: "" }
    private fun clientSecret(): String = GoogleConfig.CLIENT_SECRET.ifEmpty { prefs.getString("csec", "") ?: "" }
    /** true si la app ya trae las credenciales de Google (o ya se pegaron una vez). */
    fun hasCredentials(): Boolean = clientId().isNotEmpty() && clientSecret().isNotEmpty()
    fun builtIn(): Boolean = GoogleConfig.CLIENT_ID.isNotEmpty() && GoogleConfig.CLIENT_SECRET.isNotEmpty()
    fun connected(): Boolean = !prefs.getString("refresh", "").isNullOrEmpty()
    fun channelName(): String = prefs.getString("name", "") ?: ""
    fun cancelLogin() { cancelFlag = true }
    /** Desconectar: borra la sesión del celular Y revoca el permiso en Google (así no queda ningún acceso). */
    fun revokeAndLogout() {
        val rt = prefs.getString("refresh", "") ?: ""
        logout()
        if (rt.isNotEmpty()) {
            val th = Thread {
                try { http("POST", "https://oauth2.googleapis.com/revoke", null, "application/x-www-form-urlencoded", form("token" to rt)) }
                catch (e: Exception) { }
            }
            th.isDaemon = true
            th.start()
        }
    }
    fun logout() { prefs.edit().remove("refresh").remove("name").apply(); access = ""; expiresAt = 0L }

    // ------------------------------------------------------------------ HTTP
    private class Resp(val code: Int, val body: String)

    private fun http(method: String, url: String, auth: String?, contentType: String?, body: ByteArray?): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 40000
        if (auth != null) c.setRequestProperty("Authorization", "Bearer $auth")
        if (contentType != null) c.setRequestProperty("Content-Type", contentType)
        if (body != null && method != "GET") {
            c.doOutput = true
            c.outputStream.use { it.write(body) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        return Resp(code, text)
    }

    private fun form(vararg kv: Pair<String, String>): ByteArray =
        kv.joinToString("&") { URLEncoder.encode(it.first, "UTF-8") + "=" + URLEncoder.encode(it.second, "UTF-8") }.toByteArray()

    private fun json(s: String): JSONObject = try { if (s.isBlank()) JSONObject() else JSONObject(s) } catch (e: Exception) { JSONObject() }

    private fun errText(j: JSONObject, def: String): String {
        val e = j.opt("error")
        if (e is JSONObject) return e.optString("message", def)
        val d = j.optString("error_description")
        if (d.isNotEmpty()) return d
        if (e is String && e.isNotEmpty()) return e
        return def
    }

    // ------------------------------------------------------------------ inicio de sesión (flujo de dispositivo)
    fun startLogin(onCode: (String, String) -> Unit, onDone: (Boolean, String) -> Unit) {
        cancelFlag = false
        val t = Thread {
            try {
                val cid = clientId()
                val sec = clientSecret()
                if (cid.isEmpty() || sec.isEmpty()) { onDone(false, "Faltan las credenciales de Google de la app."); return@Thread }
                val r = http("POST", "https://oauth2.googleapis.com/device/code", null,
                    "application/x-www-form-urlencoded", form("client_id" to cid, "scope" to SCOPE))
                val j = json(r.body)
                if (r.code != 200) { onDone(false, errText(j, "No pude iniciar el acceso con Google. Revisa el ID de cliente.")); return@Thread }
                val deviceCode = j.getString("device_code")
                onCode(j.getString("user_code"), j.optString("verification_url", "https://www.google.com/device"))
                var interval = j.optInt("interval", 5)
                val end = System.currentTimeMillis() + j.optInt("expires_in", 1800) * 1000L
                while (!cancelFlag && System.currentTimeMillis() < end) {
                    Thread.sleep(interval * 1000L)
                    val t2 = http("POST", TOKEN_URL, null, "application/x-www-form-urlencoded", form(
                        "client_id" to cid, "client_secret" to sec, "device_code" to deviceCode,
                        "grant_type" to "urn:ietf:params:oauth:grant-type:device_code"
                    ))
                    val tj = json(t2.body)
                    if (tj.has("access_token")) {
                        access = tj.getString("access_token")
                        expiresAt = System.currentTimeMillis() + (tj.optInt("expires_in", 3600) - 60) * 1000L
                        prefs.edit().putString("refresh", tj.optString("refresh_token", prefs.getString("refresh", ""))).apply()
                        val name = try {
                            val ch = api("GET", "$API/channels?part=snippet&mine=true", null)
                            ch.getJSONArray("items").getJSONObject(0).getJSONObject("snippet").getString("title")
                        } catch (e: Exception) { "" }
                        prefs.edit().putString("name", name).apply()
                        onDone(true, name)
                        return@Thread
                    }
                    when (tj.optString("error")) {
                        "authorization_pending" -> { }
                        "slow_down" -> interval += 5
                        "access_denied" -> { onDone(false, "Cancelaste el permiso en Google."); return@Thread }
                        "expired_token" -> { onDone(false, "El código venció. Inténtalo de nuevo."); return@Thread }
                        else -> { onDone(false, errText(tj, "Google rechazó la conexión.")); return@Thread }
                    }
                }
                onDone(false, if (cancelFlag) "Cancelado." else "El código venció. Inténtalo de nuevo.")
            } catch (e: Exception) {
                onDone(false, "Sin conexión o error: " + (e.message ?: ""))
            }
        }
        t.isDaemon = true
        t.start()
    }

    // ------------------------------------------------------------------ token
    @Synchronized
    fun token(): String? {
        if (access.isNotEmpty() && System.currentTimeMillis() < expiresAt) return access
        val rt = prefs.getString("refresh", "") ?: ""
        if (rt.isEmpty()) return null
        val r = http("POST", TOKEN_URL, null, "application/x-www-form-urlencoded", form(
            "client_id" to clientId(), "client_secret" to clientSecret(),
            "refresh_token" to rt, "grant_type" to "refresh_token"
        ))
        val j = json(r.body)
        if (!j.has("access_token")) {
            if (j.optString("error") == "invalid_grant") logout()
            return null
        }
        access = j.getString("access_token")
        expiresAt = System.currentTimeMillis() + (j.optInt("expires_in", 3600) - 60) * 1000L
        return access
    }

    private fun api(method: String, url: String, body: JSONObject?): JSONObject {
        val t = token() ?: throw Exception("Tu sesión de Google venció. Vuelve a conectar.")
        val bytes = if (method == "GET" || method == "DELETE") null else (body?.toString() ?: "").toByteArray()
        val r = http(method, url, t, "application/json; charset=UTF-8", bytes)
        val j = json(r.body)
        if (r.code !in 200..299) throw Exception(errText(j, "Error de YouTube (${r.code})"))
        return j
    }

    // ------------------------------------------------------------------ directo
    /** Crea el evento en tu canal (título, descripción, privacidad, miniatura) y devuelve la dirección y clave RTMP. */
    fun create(title: String, desc: String, privacy: String, thumbB64: String): JSONObject {
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(System.currentTimeMillis() + 30_000))
        val bc = api("POST", "$API/liveBroadcasts?part=snippet,status,contentDetails", JSONObject()
            .put("snippet", JSONObject().put("title", title).put("description", desc).put("scheduledStartTime", iso))
            .put("status", JSONObject().put("privacyStatus", privacy).put("selfDeclaredMadeForKids", false))
            .put("contentDetails", JSONObject()
                .put("enableAutoStart", true).put("enableAutoStop", true).put("enableDvr", true)
                .put("monitorStream", JSONObject().put("enableMonitorStream", false))))
        val bid = bc.getString("id")

        val ls = api("POST", "$API/liveStreams?part=snippet,cdn,contentDetails", JSONObject()
            .put("snippet", JSONObject().put("title", "MC Voice " + bid))
            .put("cdn", JSONObject().put("frameRate", "variable").put("ingestionType", "rtmp").put("resolution", "variable"))
            .put("contentDetails", JSONObject().put("isReusable", false)))
        val sid = ls.getString("id")
        val info = ls.getJSONObject("cdn").getJSONObject("ingestionInfo")

        api("POST", "$API/liveBroadcasts/bind?id=$bid&part=id,contentDetails&streamId=$sid", null)

        var thumbMsg = ""
        if (thumbB64.isNotEmpty()) {
            try {
                val bytes = android.util.Base64.decode(thumbB64, android.util.Base64.DEFAULT)
                val t = token() ?: throw Exception("sin sesión")
                val r = http("POST", "https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId=$bid&uploadType=media",
                    t, "image/jpeg", bytes)
                if (r.code !in 200..299) thumbMsg = "No se pudo poner la miniatura: " + errText(json(r.body), "error ${r.code}")
            } catch (e: Exception) { thumbMsg = "No se pudo poner la miniatura: " + (e.message ?: "") }
        }
        return JSONObject().put("ok", true).put("videoId", bid)
            .put("url", info.getString("ingestionAddress")).put("key", info.getString("streamName"))
            .put("thumbMsg", thumbMsg)
    }

    /** status: "live" (poner en vivo) o "complete" (terminar). */
    fun transition(id: String, status: String) {
        api("POST", "$API/liveBroadcasts/transition?broadcastStatus=$status&id=$id&part=status", null)
    }

    /**
     * Termina un directo SIN borrar nunca una grabación:
     *  - en vivo / probando  -> lo completa (queda el archivo del directo)
     *  - programado (nunca salió en vivo) -> lo borra, así no queda "programado" para siempre
     *  - ya terminado -> no hace nada
     */
    fun end(id: String): String {
        val j = api("GET", "$API/liveBroadcasts?part=status&id=$id", null)
        val items = j.optJSONArray("items")
        if (items == null || items.length() == 0) return "gone"
        return when (items.getJSONObject(0).getJSONObject("status").optString("lifeCycleStatus")) {
            "live", "liveStarting", "testing", "testStarting" -> { transition(id, "complete"); "complete" }
            "created", "ready" -> { api("DELETE", "$API/liveBroadcasts?id=$id", null); "deleted" }
            else -> "done"
        }
    }

    /** Directos de tu canal que siguen en vivo o programados (para cerrarlos a mano). */
    fun pending(): JSONObject {
        val out = org.json.JSONArray()
        for (st in listOf("active", "upcoming")) {
            val j = api("GET", "$API/liveBroadcasts?part=id,snippet,status&broadcastStatus=$st&maxResults=25", null)
            val items = j.optJSONArray("items") ?: continue
            for (n in 0 until items.length()) {
                val it = items.getJSONObject(n)
                out.put(JSONObject().put("id", it.getString("id"))
                    .put("title", it.getJSONObject("snippet").optString("title"))
                    .put("state", it.getJSONObject("status").optString("lifeCycleStatus")))
            }
        }
        return JSONObject().put("ok", true).put("items", out)
    }
}
