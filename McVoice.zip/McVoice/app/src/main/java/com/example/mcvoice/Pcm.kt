package com.example.mcvoice

/**
 * Cola de audio (tu voz + voces de amigos) que llega desde la página y se mezcla en la grabación.
 * Mantiene un colchón de ~70 ms y corrige la diferencia de relojes estirando/encogiendo el audio
 * apenas (sin saltos), para evitar los "clics" y la estática.
 */
object Pcm {
    private const val SIZE = 44100 * 2
    private const val TARGET = 3000.0
    private val ring = ShortArray(SIZE)
    private var r = 0
    private var w = 0
    private var count = 0
    private var primed = false
    private var avg = TARGET

    @Synchronized fun clear() { r = 0; w = 0; count = 0; primed = false; avg = TARGET }

    @Synchronized fun put(src: ShortArray, n: Int) {
        for (i in 0 until n) {
            if (count == SIZE) { r = (r + 1) % SIZE; count-- }
            ring[w] = src[i]; w = (w + 1) % SIZE; count++
        }
    }

    /** Llena dst[0 until n]. Si no hay datos suficientes, sale silencio con fundido. Devuelve n. */
    @Synchronized fun take(dst: ShortArray, n: Int): Int {
        if (!primed) {
            if (count >= TARGET) primed = true
            else { for (i in 0 until n) dst[i] = 0; return n }
        }
        if (count > 22050) {                       // acumuló demasiado: recortar una vez
            val drop = count - TARGET.toInt()
            r = (r + drop) % SIZE; count -= drop; avg = TARGET
        }
        avg += (count - avg) * 0.02
        val delta = ((avg - TARGET) / 1000.0).toInt().coerceIn(-2, 2)
        val srcN = n + delta
        if (count < srcN + 1) {
            val m = minOf(count, n)
            for (i in 0 until m) dst[i] = (ring[(r + i) % SIZE] * (1f - (i + 1f) / m)).toInt().toShort()
            for (i in m until n) dst[i] = 0
            r = (r + count) % SIZE; count = 0; primed = false; avg = TARGET
            return n
        }
        val step = (srcN - 1).toDouble() / (n - 1)
        for (i in 0 until n) {
            val pos = i * step
            val i0 = pos.toInt()
            val f = (pos - i0).toFloat()
            val a = ring[(r + i0) % SIZE].toInt()
            val b = ring[(r + i0 + 1) % SIZE].toInt()
            dst[i] = (a + (b - a) * f).toInt().toShort()
        }
        r = (r + srcN) % SIZE; count -= srcN
        return n
    }
}
